// Named assembly parts in millimetres, initially shown retracted.

function buildPart0() {
  const feature0 = box(107, 50, 47).translate(0, 0, -23.5).translate(-6.5, -1, 23.5);
  let body = feature0;
  const feature1 = box(103, 50, 43).translate(0, 0, -21.5).translate(-6.5, 1, 23.5);
  body = difference(body, feature1);
  const feature2 = box(8, 21, 12).translate(0, 0, -6).translate(46, 0, 9);
  body = difference(body, feature2);
  const feature3 = box(32, 6, 19).translate(0, 0, -9.5).translate(0, -25, 24);
  body = difference(body, feature3);
  const feature4 = cylinder(6, 15, 15, 64).translate(0, 0, -3).rotate([1,0,0], 90).translate(-38, -25, 24);
  body = difference(body, feature4);
  const feature5 = cylinder(6, 3.65, 3.65, 64).translate(0, 0, -3).rotate([1,0,0], 90).translate(32, -25, 24);
  body = difference(body, feature5);
  const feature6 = box(18, 12, 3).translate(0, 0, -1.5).translate(34, 0, 3.4);
  body = union(body, feature6);
  const feature7 = box(24, 3, 9).translate(0, 0, -4.5).translate(-47, -10, 24);
  body = union(body, feature7);
  const feature8 = cylinder(5, 2.6, 2.6, 64).translate(0, 0, -2.5).rotate([1,0,0], 90).translate(-38, -10, 24);
  body = difference(body, feature8);
  const feature9 = box(56, 48, 5).translate(0, 0, -2.5).translate(-6.5, 36, 47.5);
  body = union(body, feature9);
  const feature10 = box(56, 8, 27).translate(0, 0, -13.5).translate(-6.5, 22, 61);
  body = union(body, feature10);
  const feature11 = box(56, 42, 6).translate(0, 0, -3).translate(-6.5, 39, 72.6);
  body = union(body, feature11);
  return body;
}

function buildPart1() {
  const feature0 = box(107, 2, 45).translate(0, 0, -22.5).translate(0, 1, 22.5);
  let body = feature0;
  const feature1 = box(102.6, 3.2, 42.6).translate(0, 0, -21.3).translate(0, -1.4, 23.5);
  body = union(body, feature1);
  const feature2 = box(99.4, 3.4, 39.4).translate(0, 0, -19.7).translate(0, -1.5, 23.5);
  body = difference(body, feature2);
  const feature3 = box(12, 8, 5).translate(0, 0, -2.5).translate(0, 0, 0);
  body = difference(body, feature3);
  return body;
}

function buildPart2() {
  const feature0 = cylinder(1.5, 17.5, 17.5, 64).translate(0, 0, -0.75).rotate([1,0,0], 90).translate(0, 0, 0);
  let body = feature0;
  return body;
}

function buildPart3() {
  const feature0 = cylinder(5.9, 2.5, 2.5, 64).translate(0, 0, -2.95).rotate([1,0,0], 90).translate(0, -2.85, 0);
  let body = feature0;
  const feature1 = sphere(1, 48).scale([2.5,2.5,2.5]).translate(0, -5.7, 0);
  body = union(body, feature1);
  const feature2 = cylinder(0.8, 2.9, 2.9, 64).translate(0, 0, -0.4).rotate([1,0,0], 90).translate(0, 0.4, 0);
  body = union(body, feature2);
  const feature3 = box(0.5, 5.2, 0.5).translate(0, 0, -0.25).translate(-1.27, 3.3, 0);
  body = union(body, feature3);
  const feature4 = box(0.5, 4.2, 0.5).translate(0, 0, -0.25).translate(1.27, 2.8, 0);
  body = union(body, feature4);
  return body;
}

function buildPart4() {
  // Embedded CC0-1.0 dimensional reference: xiao-esp32s3 (millimetres).
  function catalogBoard(Param, param) {
    // Original simplified Seeed Studio XIAO ESP32S3 base board, headerless.
    // Coordinates in mm: origin at PCB centre on the underside, USB port faces +X.
    const groupId = typeof Param === "undefined" ? param('Material group', 0, {min:0,max:4,step:1}) : Param.number('Material group', 0, {min:0,max:4,step:1});
    const L=20.955, W=17.78, pcbTop=1.25;
    const block=(x,y,z,w,d,h)=>box(w,d,h).moveTo(x-w/2,y-d/2,z);
    const rounded=(x,y,z,w,d,h,r)=>roundedRect(w,d,r).extrude(h).moveTo(x-w/2,y-d/2,z);
    const disc=(x,y,z,diameter,h)=>cylinder(h,diameter/2,diameter/2,16).translate(x,y,z);
    const footprint=rounded(0,0,.035,L,W,pcbTop-.035,1.5);
    const holes=[], contacts=[];
    for(let row=-1;row<=1;row+=2)for(let n=0;n<7;n++){
      const x=(n-3)*2.54, y=row*7.62, edge=row*W/2;
      const drill=disc(x,y,-.1,.86,1.6), castellated=disc(x,edge,-.1,.76,1.6);
      holes.push(drill,castellated);
      const pad=block(x,row*8.14,0,1.6,1.49,.035);
      for(const z of [0,pcbTop])contacts.push(difference(pad.translate(0,0,z),drill,castellated));
    }
    const pcb=difference(footprint,...holes);
    for(const x of [-4.85,-2.31,.23,2.77])for(const y of [-1.85,1.85])contacts.push(disc(x,y,0,1.35,.035));
    contacts.push(block(-6.7,0,0,2.55,2.55,.035),block(-2.7,-4.7,0,2.0,1.0,.035));
    // Reference port aperture, two retention windows and a polymer tongue.
    const portRear=4.7045,portFront=12.0045,portWidth=8.94;
    const portSolid=(x,z,len,width,height,r)=>roundedRect(width,height,r).extrude(len)
      .rotate([1,1,1],120).moveTo(x,-width/2,z);
    const usb=difference(portSolid(portRear,1.15,portFront-portRear,portWidth,3.31,.7),
      portSolid(portRear+.5,1.43,7.4,8.15,2.70,.58),
      block(8.03,-1.57,4.12,1.00,1.22,.60),block(8.03,1.57,4.12,1.00,1.22,.60));
    const shield=rounded(-1.5325,0,pcbTop,10.60,12.60,2,.32);
    const frames=[],caps=[];
    for(const y of [-5.93,5.93]){
      frames.push(rounded(8.895,y,pcbTop,2.60,1.60,.55,.18));
      caps.push(rounded(8.905,y,pcbTop+.54,1.56,1.14,.24,.23));
    }
    const antennaX=-8.7565,antennaY=4.727;
    const socketRing=difference(disc(antennaX,antennaY,1.62,2.08,.88),disc(antennaX,antennaY,1.66,1.36,.98));
    contacts.push(socketRing,disc(antennaX,antennaY,1.66,.48,.47));
    const dark=[block(9.32,0,2.50,4.60,6.70,.51),rounded(antennaX,antennaY,pcbTop,3,3.1,.46,.25),...caps];
    const layers=[pcb,union(...contacts),union(usb,shield,...frames),union(...dark)];
    return groupId===0?union(...layers):layers[groupId-1];
  }
  const materials = group(
    {name:"基础版 PCB 轮廓、通孔和侧面半孔", shape:catalogBoard({number:()=>1}, ()=>1).color("#2a3138")},
  {name:"镀金排焊盘、底面测试点与天线座", shape:catalogBoard({number:()=>2}, ()=>2).color("#d0a34c")},
  {name:"USB-C 壳、中央屏蔽罩和按钮座", shape:catalogBoard({number:()=>3}, ()=>3).color("#b9c3ca")},
  {name:"USB-C 舌片、侧键和天线座底托", shape:catalogBoard({number:()=>4}, ()=>4).color("#393f45")}
  );
  return materials.translate(-0.7635000000000005, 0, -2.23).translate(0.7635000000000005, 0, 2.23);
}

function buildPart5() {
  const feature0 = box(12, 6.5, 14).translate(0, 0, -7).translate(0, 3.2, 0);
  let body = feature0;
  const feature1 = box(10, 1, 20).translate(0, 0, -10).translate(0, 5.8, 0);
  body = union(body, feature1);
  const feature2 = box(14, 1, 3).translate(0, 0, -1.5).translate(0, 6.2, 0);
  body = union(body, feature2);
  const feature3 = box(1, 4.1, 2).translate(0, 0, -1).translate(-6.6, 8.4, 0);
  body = union(body, feature3);
  const feature4 = box(1, 4.1, 2).translate(0, 0, -1).translate(6.6, 8.4, 0);
  body = union(body, feature4);
  const feature5 = cylinder(5.1, 3.5, 3.5, 64).translate(0, 0, -2.55).rotate([1,0,0], 90).translate(0, -2.5, 0);
  body = union(body, feature5);
  const feature6 = cylinder(1.8, 5, 5, 64).translate(0, 0, -0.9).rotate([1,0,0], 90).translate(0, -3.25, 0);
  body = union(body, feature6);
  const feature7 = cylinder(9, 3.1, 3.1, 64).translate(0, 0, -4.5).rotate([1,0,0], 90).translate(0, -1.5, 0);
  body = difference(body, feature7);
  // Five electrical terminals reconstructed from the Bourns PEC11 drawing.
  // https://cdn-shop.adafruit.com/datasheets/pec11.pdf
  return group(
    {name:"固定座与机械焊耳", shape:body},
    {name:"A 电气脚", shape:box(0.45, 3.5, 0.4).translate(0, 0, -0.2).translate(-2.5, 8.05, -7.5).color("#BEBAB0")},
  {name:"C 电气脚", shape:box(0.45, 3.5, 0.4).translate(0, 0, -0.2).translate(0, 8.05, -7.5).color("#BEBAB0")},
  {name:"B 电气脚", shape:box(0.45, 3.5, 0.4).translate(0, 0, -0.2).translate(2.5, 8.05, -7.5).color("#BEBAB0")},
  {name:"SW1 电气脚", shape:box(0.45, 3.5, 0.4).translate(0, 0, -0.2).translate(-2.5, 8.05, 7).color("#BEBAB0")},
  {name:"SW2 电气脚", shape:box(0.45, 3.5, 0.4).translate(0, 0, -0.2).translate(2.5, 8.05, 7).color("#BEBAB0")}
  );
}

function buildPart6() {
  // Placement envelope (mm); editable component geometry is not included for this part.
  const feature0 = box(10.754, 2.5, 5.499).translate(0, 0, -2.7495).translate(0, 0, 0);
  let body = feature0;
  return body;
}

function buildPart7() {
  // Adafruit source STEP and matching display meshes are bundled with their licenses.
  // Meshes preserve this assembly’s material groups, including EAGLE-derived plated rings.
  const materials = group(
    {name:"四孔 PCB 与八针焊排", shape:importMesh("./assets/hardware/adafruit-938-qt/pcb.stl").color("#27425c")},
  {name:"OLED 玻璃与屏面", shape:importMesh("./assets/hardware/adafruit-938-qt/glass.stl").color("#17202b")},
  {name:"OLED 柔性排线", shape:importMesh("./assets/hardware/adafruit-938-qt/flex.stl").color("#a95a26")},
  {name:"两侧 STEMMA QT 插座", shape:importMesh("./assets/hardware/adafruit-938-qt/sockets.stl").color("#e2dac7")},
  {name:"稳压器、二极管和电平转换器", shape:importMesh("./assets/hardware/adafruit-938-qt/ic.stl").color("#35373c")},
  {name:"阻容器件与板载指示灯", shape:importMesh("./assets/hardware/adafruit-938-qt/passives.stl").color("#94856f")},
  {name:"JP2 与安装孔双面焊环", shape:importMesh("./assets/hardware/adafruit-938-qt/pads.stl").color("#caa857")}
  );
  return materials.translate(0, -0.4818, 0).translate(0, 0.4818, 0);
}

function buildPart8() {
  // Placement envelope (mm); editable component geometry is not included for this part.
  const feature0 = box(48, 28, 1).translate(0, 0, -0.5).translate(0, 0, 0);
  let body = feature0;
  return body;
}

function buildPart9() {
  // Placement envelope (mm); editable component geometry is not included for this part.
  const feature0 = box(48, 28, 1).translate(0, 0, -0.5).translate(0, 0, 0);
  let body = feature0;
  return body;
}

function buildPart10() {
  const feature0 = cylinder(15, 3, 3, 64).translate(0, 0, -7.5).rotate([1,0,0], 90).translate(0, -7.5, 0);
  let body = feature0;
  const feature1 = cylinder(14.5, 8, 8, 64).translate(0, 0, -7.25).rotate([1,0,0], 90).translate(0, -14.6, 0);
  body = union(body, feature1);
  const feature2 = box(1, 0.6, 4).translate(0, 0, -2).translate(0, -21.85, 5);
  body = difference(body, feature2);
  return body;
}

function buildPart11() {
  const feature0 = cylinder(0.3, 5, 5, 64).translate(0, 0, -0.15).rotate([1,0,0], 90).translate(0, 0, 0);
  let body = feature0;
  const feature1 = cylinder(1, 3.7, 3.7, 64).translate(0, 0, -0.5).rotate([1,0,0], 90).translate(0, 0, 0);
  body = difference(body, feature1);
  return body;
}

// 参考线束：用于查看连接关系。线径和走向是示意值，不用于打印、裁线或干涉验证。
function referenceWire(points, color) {
  const radius = 0.38; // Illustrative insulation radius in mm.
  const pieces = [];
  for (let i = 1; i < points.length; i++) {
    const a = points[i - 1], b = points[i];
    const dx = b[0] - a[0], dy = b[1] - a[1], dz = b[2] - a[2];
    const length = Math.hypot(dx, dy, dz), horizontal = Math.hypot(dx, dy);
    let leg = cylinder(length, radius, radius, 12);
    if (horizontal > 0) leg = leg.rotate([-dy / horizontal, dx / horizontal, 0], Math.atan2(horizontal, dz) * 180 / Math.PI);
    else if (dz < 0) leg = leg.rotate([1, 0, 0], 180);
    pieces.push(leg.translate(...a));
    if (i < points.length - 1) pieces.push(sphere(radius, 12).translate(...b));
  }
  return (pieces.length === 1 ? pieces[0] : union(...pieces)).color(color);
}

const mechanism = assembly("Formwork");
mechanism.addFrame("Assembly origin");
mechanism.addPart("前壳、夹脚、板托与贯孔灯座", buildPart0().translate(0, 0, 0));
mechanism.addPart("后盖与四边定位唇", buildPart1().translate(-6.5, 24, 0));
mechanism.addPart("正面乳白灯片", buildPart2().translate(-38, -22.25, 24));
mechanism.addPart("单灯：透镜、穿孔灯身、后止挡法兰及双脚", buildPart3().translate(-38, -8.5, 24));
mechanism.addPart("XIAO ESP32S3 无排针基础板、板边焊盘与右向开口 USB-C", buildPart4().translate(33.9955, 0, 5.9));
mechanism.addPart("377 固定座、端脚、轴套与外螺母承面", buildPart5().translate(32, -23.65, 24));
mechanism.addPart("LED 阴极限流电阻", buildPart6().translate(-33, -3, 32));
mechanism.addPart("938 前向屏、四孔板与双 QT 插座", buildPart7().translate(0, -21, 24));
mechanism.addPart("下夹脚软垫", buildPart8().translate(-6.5, 43, 50.5));
mechanism.addPart("上夹脚软垫", buildPart9().translate(-6.5, 43, 69.1));
mechanism.addFrame("Motion frame 1");
mechanism.addPrismatic("1. 旋钮按压", "Assembly origin", "Motion frame 1", {axis:[0,1,0], min:0, max:0.5, default:0, unit:"mm", frame:Transform.identity().translate(32, -23.65, 24)});
mechanism.addFrame("Motion frame 2");
mechanism.addRevolute("2. 旋钮转动", "Motion frame 1", "Motion frame 2", {axis:[0,1,0], min:-15, max:15, default:0, unit:"deg", frame:Transform.identity().translate(0, 0, 0)});
mechanism.addPart("旋钮帽与可按压轴（自由态）", buildPart10().translate(0, 0, 0));
mechanism.addFixed("Attach 旋钮帽与可按压轴（自由态）", "Motion frame 2", "旋钮帽与可按压轴（自由态）");
mechanism.addPart("固定座内侧承力垫圈", buildPart11().translate(32, -23.85, 24));
mechanism.addPart("参考线束 · 控制板 3V3 → 正面分钟屏 VIN", referenceWire([[36.5355,-8.3,7.1850000000000005],[36.5355,-8.3,12.185],[34.838822123798664,-9.173515396306122,14.951825482190273],[33.09003708136115,-10.026659066529238,17.67653014168731],[31.240588723719114,-10.840447584053035,20.31986362025646],[29.2487809404814,-11.598579510880189,22.848120871171083],[27.08261918085112,-12.28854631369249,25.235439102446733],[24.72199082938898,-12.902484799725144,27.465560283374618],[22.160035847517783,-13.437712980359159,29.532939102446733],[19.403614273814732,-13.896912844213523,31.443120871171082],[16.472838723719114,-14.287947584053036,33.21236362025646],[13.39970374802782,-14.623325733195905,34.866530141687306],[10.225905457132002,-14.919348729639456,36.43932548219027],[7,-15.195,37.97],[7,-20.195,37.97]], "#D65A4B"));
mechanism.addPart("参考线束 · 控制板 GND → 正面分钟屏 GND", referenceWire([[39.0755,-8.3,7.1850000000000005],[39.0755,-8.3,12.185],[37.23862320745707,-8.825398952959572,14.951825482190273],[35.35919357313698,-9.354149740160585,17.67653014168731],[33.397558161107774,-9.88937577388009,20.31986362025646],[31.319666223336927,-10.43375918904576,22.848120871171083],[29.099389701898183,-10.989358060172997,25.235439102446733],[26.720303812940625,-11.557466146987835,27.465560283374618],[24.176806368564847,-12.138524726839664,29.532939102446733],[21.47449955667026,-12.732092522379094,31.443120871171082],[18.62980816110778,-13.336875773880092,33.21236362025646],[15.668860239803644,-13.950816406827252,34.866530141687306],[12.625706540790405,-14.571232286292906,36.43932548219027],[9.54,-15.195,37.97],[9.54,-20.195,37.97]], "#465564"));
mechanism.addPart("参考线束 · 控制板 D4 → 正面分钟屏 SDA", referenceWire([[31.4555,8.3,7.1850000000000005],[31.4555,8.3,12.185],[29.081358169960637,7.114632283034741,14.607645159679954],[26.695318808280966,5.912614540558348,16.999537649417803],[24.28600436254405,4.67802443307021,19.3312688385156],[21.843054513192495,3.3963631897202786,21.57605943379932],[19.357578969207452,2.0551892741680344,23.71092986323185],[16.822546016486466,0.6446621394216845,25.717704593479276],[14.233089837491677,-0.8420276930381096,27.58380648793341],[11.586723170825012,-2.408361026371442,29.30280648793341],[8.883446016486467,-4.054337860578313,30.874704593479272],[6.125745635874117,-5.776477392498633,32.30592986323185],[3.318487846525829,-7.567970143613055,33.60905943379932],[0.4687043625440457,-9.418975566929792,34.80226883851561],[-2.414714525052373,-11.31705212610832,35.9085376494178],[-5.3214084967060336,-13.247701050298593,36.95464515967995],[-8.24,-15.195,37.97],[-8.24,-20.195,37.97]], "#D99A27"));
mechanism.addPart("参考线束 · 控制板 D5 → 正面分钟屏 SCL", referenceWire([[28.9155,8.3,7.1850000000000005],[28.9155,8.3,12.185],[26.524350255479234,7.315653600701678,14.760551556735654],[24.129119478596238,6.296513768238489,17.29930903019154],[21.725931276992334,5.209531757469176,19.766323346062254],[19.311308276811666,4.0250607133570195,22.130242931537044],[16.882346492746557,2.718342288075859,24.36488581407332],[14.43686094598688,1.270748127951959,26.450552494826326],[11.973495228181202,-0.3292860230975645,28.375013763779158],[9.491789517415452,-2.0856804434766123,30.134123923397755],[6.9922036356036985,-3.9945148547812854,31.732028671216177],[4.476093991097374,-6.044225000928695,33.18095721725133],[1.945645562706616,-8.216182528245112,34.50060906034797],[-0.5962376642609067,-10.485629088904368,35.71716617304868],[-3.146078315949344,-12.82291782786975,36.86198012816423],[-5.7,-15.195,37.97],[-5.7,-20.195,37.97]], "#D99A27"));
mechanism.addPart("参考线束 · 面板编码器与旋钮帽 A → 控制板 D0", referenceWire([[29.5,-13.849999999999998,16.5],[29.5,-9.275208509043825,16.5],[32.48016486064435,-7.1023402940386315,16.64439502083349],[35.212874858722685,-4.862551621637453,16.626068489750992],[37.499686602034934,-2.5021764517571286,16.31452785384235],[39.23047231632065,0.008567620963417233,15.637355209693231],[40.405232001579826,2.669680596524186,14.594550557303638],[41.134093432072916,5.451380069564101,13.258531800087898],[41.6155,8.3,11.759791490956172],[41.6155,8.3,7.1850000000000005]], "#D99A27"));
mechanism.addPart("参考线束 · 面板编码器与旋钮帽 B → 控制板 D1", referenceWire([[34.5,-13.849999999999998,16.5],[34.5,-9.691677244401895,16.5],[35.83108731695423,-6.951854876359417,16.499338832159328],[37.02799845033175,-4.245620454067582,16.352902449468207],[37.98313245527612,-1.5999094186919935,15.943788206193002],[38.63677531241898,0.9703301876511341,15.207120028421302],[38.988927021760325,3.465098364961803,14.14289791615311],[39.09930160266852,5.899343155356221,12.815997943300832],[39.0755,8.3,11.343322755598104],[39.0755,8.3,7.1850000000000005]], "#D99A27"));
mechanism.addPart("参考线束 · 控制板 GND → 面板编码器与旋钮帽 C", referenceWire([[39.0755,-8.3,7.1850000000000005],[39.0755,-8.3,9.386053131963198],[38.17109663810331,-8.642568970766591,10.908929993552741],[37.193048341484435,-9.042904797261846,12.341449282955383],[36.08744327620663,-9.543295752872648,13.617464666481748],[34.834548341484435,-10.159220419940779,14.712764905634316],[33.45409663810331,-10.875200216124458,15.651561238910608],[32,-11.6489468680368,16.5],[32,-13.849999999999998,16.5]], "#465564"));
mechanism.addPart("参考线束 · 面板编码器与旋钮帽 SW1 → 控制板 D3", referenceWire([[29.5,-13.849999999999998,31],[29.5,-8.849999999999998,31],[29.634987084051946,-6.247118412058945,29.48920945824643],[29.813939805404917,-3.728344635059752,27.908490699408024],[30.07552089663774,-1.3676418366456033,26.196349881410942],[30.448426889456865,0.7800925084368568,24.307144602098898],[30.947926889456863,2.6856480639924127,22.216589046543344],[31.57402089663774,4.3490248300210625,19.924683214744277],[32.311439805404916,5.799433142718026,17.455712921630248],[33.13148708405195,7.091770476829942,14.855320569357547],[33.9955,8.3,12.185],[33.9955,8.3,7.1850000000000005]], "#D99A27"));
mechanism.addPart("参考线束 · 控制板 GND → 面板编码器与旋钮帽 SW2", referenceWire([[39.0755,-8.3,7.1850000000000005],[39.0755,-8.3,11.414181556722884],[37.15211781068161,-7.699544233115779,14.152111846334476],[35.48022306843156,-7.255388136607714,16.901934541718628],[34.261493047135176,-7.09287431424431,19.67318661183386],[33.60785018999231,-7.281562663283897,22.47116067515916],[33.51929449700299,-7.821453183726477,25.295856731694535],[33.88390352496732,-8.642985978313716,28.14198216296099],[34.5,-9.620818443277113,31],[34.5,-13.849999999999998,31]], "#465564"));
mechanism.addPart("参考线束 · 控制板 D10 → 柔光提示灯 A", referenceWire([[33.9955,-8.3,7.1850000000000005],[33.9955,-8.3,12.185],[30.285831016917697,-7.748232688776966,13.448633693989494],[26.572168351671962,-7.19615467212871,14.694760986464344],[22.850627259338026,-6.643463719864063,15.906353004907434],[19.117537897944562,-6.089874321077665,17.067322909050503],[15.369545432196096,-5.5351254721431955,18.162964697941394],[11.603701544634463,-4.978987796211912,19.180354351314328],[7.817544858053381,-4.4212698000151445,20.10870236317238],[4.009168075452297,-3.8618230973014764,20.939648051384907],[0.17727000612663057,-3.3005464564268703,21.6674876153014],[-3.678808941241793,-2.737388561690028,22.28932972056456],[-7.559068766652968,-2.1723494130909486,22.80517436717438],[-11.462849878788724,-1.6054803263309336,23.21791288948817],[-15.388851086944484,-1.0368825330540168,23.533249088156435],[-19.33516509411969,-0.46670441951161623,23.75954364530981],[-23.299330523108075,0.10486252102759883,23.907586066945242],[-27.27839905645145,0.6775889117148842,23.990300373328488],[-31.269015858854353,1.251213748923922,24.02239256541171],[-35.26751108834545,1.8254515217493494,24.01994948346318],[-39.27,2.4000000000000004,24],[-39.27,-2.5999999999999996,24]], "#D99A27"));
mechanism.addPart("参考线束 · 柔光提示灯 K → LED 限流电阻 1", referenceWire([[-36.73,-3.5999999999999996,24],[-36.73,-2.672755570399584,24],[-36.94939707712207,-2.52399840062479,24.698751375384717],[-37.17029545290455,-2.4297147411326603,25.40334169048528],[-37.393794154244155,-2.4297819691167315,26.118045345836027],[-37.62029545290454,-2.5387962176661323,26.844426880618478],[-37.84939707712207,-2.742161353691734,27.580921755651108],[-38.08,-3,28.323255570399585],[-38.08,-3,29.2505]], "#465564"));
mechanism.addPart("参考线束 · LED 限流电阻 2 → 控制板 GND", referenceWire([[-27.92,-3,29.2505],[-27.92,-3,24.2505],[-23.982025769045862,-3.311532318201326,24.240126388289397],[-20.050614649824748,-3.622545430005431,24.209701078406738],[-16.13213033724078,-3.932535904838741,24.13978163288229],[-12.232543751719684,-4.241031384434562,24.01212562357278],[-8.35725161581309,-4.547604935199986,23.81024491860944],[-4.510912477514678,-4.851888020377074,23.519906665941445],[-0.6973051626367253,-5.153581697845757,23.129565751343282],[3.080786042900013,-5.452465703328882,22.630715590868412],[6.821655992185107,-5.748405143010816,22.018146599097914],[10.524730487344456,-6.041354592217771,21.2901044797573],[14.190583726252166,-6.331359475623534,20.448343529121058],[17.82092085581865,-6.618554687043741,19.498073332608115],[21.41852616196469,-6.903160490755542,18.447800474164996],[24.987178470502535,-7.185475828879007,17.309070068017224],[28.531536329425887,-7.4658692381720755,16.096114966215623],[32.05699646128635,-7.744767652227654,14.825423300628966],[35.56952978650969,-8.022643429312438,13.515237499400511],[39.0755,-8.3,12.185],[39.0755,-8.3,7.1850000000000005]], "#465564"));
mechanism.toJointsView({"overrides":{},"animations":[{"name":"1. 旋钮按压","duration":2,"keyframes":[{"values":{"1. 旋钮按压":0}},{"values":{"1. 旋钮按压":0.5}},{"values":{"1. 旋钮按压":0}}]},{"name":"2. 旋钮转动","duration":2,"keyframes":[{"values":{"2. 旋钮转动":0}},{"values":{"2. 旋钮转动":15}},{"values":{"2. 旋钮转动":0}}]}]});
return mechanism.solve();
